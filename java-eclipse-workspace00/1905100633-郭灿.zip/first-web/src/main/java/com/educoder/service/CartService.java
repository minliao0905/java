package com.educoder.service;

public interface CartService {

}
