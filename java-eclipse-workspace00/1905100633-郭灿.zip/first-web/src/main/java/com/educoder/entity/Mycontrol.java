package com.educoder.entity;

public class Mycontrol {

}
