package com.educoder.service.impl;

import java.util.List;

import com.educoder.entity.Address;
import com.educoder.service.AddressService;

public class AddressServiceImpl implements AddressService {

	@Override
	public List<Address> getAddressByUserId(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

}
